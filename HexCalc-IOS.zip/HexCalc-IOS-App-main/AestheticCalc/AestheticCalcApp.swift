//
//  AestheticCalcApp.swift
//  AestheticCalc
//
//  Created by Jeriel on 9/1/24.
//

import SwiftUI

@main
struct AestheticCalcApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

# HexCalc-IOS-App
It converts the inserted number in hexadecimal.
